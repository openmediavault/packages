#!/usr/bin/phpunit -c/etc/openmediavault
<?php
/**
 * This file is part of OpenMediaVault.
 *
 * @license   http://www.gnu.org/licenses/gpl.html GPL Version 3
 * @author    Volker Theile <volker.theile@openmediavault.org>
 * @copyright Copyright (c) 2009-2019 Volker Theile
 *
 * OpenMediaVault is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * OpenMediaVault is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OpenMediaVault. If not, see <http://www.gnu.org/licenses/>.
 */
require_once("openmediavault/autoloader.inc");
require_once("openmediavault/globals.inc");

class test_openmediavault_json_schema extends \PHPUnit_Framework_TestCase {
	protected function getSchema() {
		return new \OMV\Json\Schema([
			"type" => "object",
			"properties" => [
				"name" => [
					"type" => "string",
					"required" => TRUE
				],
				"price" => [
					"type" => "number",
					"minimum" => 35,
					"maximum" => 40
				],
				"ntp" => [
					"type" => "object",
					"properties" => [
						"enable" => [
							"type" => "boolean",
							"default" => FALSE
						],
						"timeservers" => [
							"type" => "string",
							"default" => "pool.ntp.org"
						]
					]
				],
				"privilege" => [
					"type" => "array",
					"items" => [
						"type" => "object",
						"properties" => [
							"type" => [
								"type" => "string",
								"enum" => [ "user", "group" ]
							],
							"name" => [
								"type" => "string"
							],
							"perms" => [
								"type" => "integer",
								"enum" => [ 0, 5, 7 ]
							]
						]
					]
				],
				"slaves" => [
					"type" => "string",
					"pattern" => "^(((eth|wlan)\\d+|(en|wl)\\S+),)*((eth|wlan)\\d+|(en|wl)\\S+)$"
				],
				"upsname" => [
					"type" => "string",
					"pattern" => "^[a-z0-9_-]+$"
				],
				"devices" => [
					"type" => "string",
					"pattern" => "^(.+[,;])*.+$"
				],
				"hostname" => [
					"type" => "string",
					"format" => "hostname"
				]
			]
		]);
	}

	public function testGetAssoc() {
		$schema = $this->getSchema();
		$this->assertInternalType("array", $schema->getAssoc());
	}

	public function testGetAssocByPath1() {
		$schema = $this->getSchema();
		$this->assertInternalType("array", $schema->getAssocByPath("price"));
	}

	public function testGetAssocByPath2() {
		$schema = $this->getSchema();
		$this->assertEquals($schema->getAssocByPath("ntp.enable"), [
			"type" => "boolean",
			"default" => FALSE
		]);
	}

	/**
	 * @expectedException OMV\Json\SchemaPathException
	 */
	public function testGetAssocByPathFail() {
		$schema = $this->getSchema();
		$schema->getAssocByPath("a.b.c");
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidateFail() {
		$schema = $this->getSchema();
		$schema->validate(["price" => 38]);
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidateMaximumFail() {
		$schema = $this->getSchema();
		$schema->validate(["name" => "Apple", "price" => 41]);
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidateMinimumFail() {
		$schema = $this->getSchema();
		$schema->validate(["name" => "Eggs", "price" => 34.99]);
	}

	public function testValidatePattern1() {
		$schema = $this->getSchema();
		$schema->validate(["name" => "Eggs", "slaves" => "eth0"]);
	}

	public function testValidatePattern2() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "foo",
			"upsname" => utf8_encode("foo-bar_1234")
		]);
	}

	public function testValidatePattern3() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "bar",
			"devices" => utf8_encode("/dev/vdb")
		]);
	}

	public function testValidatePattern4() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "xyz",
			"hostname" => utf8_encode("omv4box")
		]);
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidatePatternFail1() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "Eggs",
			"slaves" => utf8_encode("xyz0")
		]);
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidatePatternFail2() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "foo",
			"upsname" => utf8_encode("ε体λñι語ά_1234")
		]);
	}

	/**
	 * @expectedException OMV\Json\SchemaValidationException
	 */
	public function testValidatePatternFail3() {
		$schema = $this->getSchema();
		$schema->validate([
			"name" => "xyz",
			"hostname" => utf8_encode("ε体λñ-ι語ά1234")
		]);
	}
}
