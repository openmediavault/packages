global._ = (str, params) => {}
global.gettext = (str, params) => {}
