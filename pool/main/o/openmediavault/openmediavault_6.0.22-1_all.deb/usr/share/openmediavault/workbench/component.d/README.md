Plugins must place their component manifest here.
