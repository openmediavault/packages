/**
 * Created by JetBrains PhpStorm.
 * User: mbeck
 * Date: 28.11.11
 * Time: 20:38
 * To change this template use File | Settings | File Templates.
 */
// require("js/omv/NavigationPanel.js")

OMV.NavigationPanelMgr.registerMenu("services", "transmissionbt", {
	text: "BitTorrent",
	icon: "images/transmissionbt.png",
	position: 20
});
