The files in this directory have been obtained form the following places:

cgi.d
	https://github.com/adamdruppe/arsd/blob/a870179988b8881b04126856105f0fad2cc0018d/cgi.d
	License: Boost Software License - Version 1.0

    Copyright 2008-2021, Adam D. Ruppe
	see https://github.com/adamdruppe/arsd/blob/a870179988b8881b04126856105f0fad2cc0018d/LICENSE
