proftpd-mod_vroot
=================

ProFTPD module that creates "virtual" chroots