
#ifndef __FFMPEG_URL_EVBUFFER_H__
#define __FFMPEG_URL_EVBUFFER_H__

int
register_ffmpeg_evbuffer_url_protocol(void);

#endif /* !__FFMPEG_URL_EVBUFFER_H__ */
