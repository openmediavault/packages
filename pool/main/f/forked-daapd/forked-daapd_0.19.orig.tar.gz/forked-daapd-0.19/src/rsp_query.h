
#ifndef __RSP_QUERY_H__
#define __RSP_QUERY_H__


char *
rsp_query_parse_sql(const char *rsp_query);

#endif /* !__RSP_QUERY_H__ */
