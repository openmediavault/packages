
#ifndef __DAAP_QUERY_H__
#define __DAAP_QUERY_H__

#include "logger.h"
#include "misc.h"


char *
daap_query_parse_sql(const char *daap_query);

#endif /* !__DAAP_QUERY_H__ */
